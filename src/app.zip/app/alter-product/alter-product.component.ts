import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-alter-product',
  templateUrl: './alter-product.component.html',
  styleUrls: ['./alter-product.component.scss']
})
export class AlterProductComponent implements OnInit {

 
  product = {
    name: '',
    price: 100,
    wireless: false,
    touchscreen : false,
    interoperable : false
  };
  submitted = false;

  constructor(private productservice: ProductService) { }

  ngOnInit(): void {
  }
  saveProduct() {
    const data = {
      name: this.product.name,
      price: this.product.price,
      wireless: this.product.wireless,
      touchscreen: this.product.touchscreen,
      interoperable: this.product.interoperable
    };

    this.productservice.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  /*newProduct() {
    this.submitted = false;
    this.product = {
      
    };
  }*/

}
